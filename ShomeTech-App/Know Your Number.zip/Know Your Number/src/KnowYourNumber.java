
import javax.swing.JOptionPane;
public class KnowYourNumber extends javax.swing.JFrame {
    public KnowYourNumber() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jOptionPane = new javax.swing.JOptionPane();
        no = new javax.swing.JRadioButton();
        buttonGroup1 = new javax.swing.ButtonGroup();
        armI = new javax.swing.JFrame();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jScrollPane5 = new javax.swing.JScrollPane();
        i1 = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        i2 = new javax.swing.JTextArea();
        jScrollPane7 = new javax.swing.JScrollPane();
        i3 = new javax.swing.JTextArea();
        autoI = new javax.swing.JFrame();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jScrollPane8 = new javax.swing.JScrollPane();
        i4 = new javax.swing.JTextArea();
        jScrollPane9 = new javax.swing.JScrollPane();
        i5 = new javax.swing.JTextArea();
        jScrollPane10 = new javax.swing.JScrollPane();
        i6 = new javax.swing.JTextArea();
        bounI = new javax.swing.JFrame();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jScrollPane11 = new javax.swing.JScrollPane();
        i7 = new javax.swing.JTextArea();
        jScrollPane12 = new javax.swing.JScrollPane();
        i8 = new javax.swing.JTextArea();
        jScrollPane13 = new javax.swing.JScrollPane();
        i9 = new javax.swing.JTextArea();
        disI = new javax.swing.JFrame();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jScrollPane14 = new javax.swing.JScrollPane();
        i10 = new javax.swing.JTextArea();
        jScrollPane15 = new javax.swing.JScrollPane();
        i11 = new javax.swing.JTextArea();
        jScrollPane16 = new javax.swing.JScrollPane();
        i12 = new javax.swing.JTextArea();
        decI = new javax.swing.JFrame();
        jTabbedPane6 = new javax.swing.JTabbedPane();
        jScrollPane17 = new javax.swing.JScrollPane();
        i13 = new javax.swing.JTextArea();
        jScrollPane18 = new javax.swing.JScrollPane();
        i14 = new javax.swing.JTextArea();
        jScrollPane19 = new javax.swing.JScrollPane();
        i15 = new javax.swing.JTextArea();
        ducI = new javax.swing.JFrame();
        jTabbedPane7 = new javax.swing.JTabbedPane();
        jScrollPane20 = new javax.swing.JScrollPane();
        i16 = new javax.swing.JTextArea();
        jScrollPane21 = new javax.swing.JScrollPane();
        i17 = new javax.swing.JTextArea();
        jScrollPane22 = new javax.swing.JScrollPane();
        i18 = new javax.swing.JTextArea();
        eviI = new javax.swing.JFrame();
        jTabbedPane9 = new javax.swing.JTabbedPane();
        jScrollPane26 = new javax.swing.JScrollPane();
        i22 = new javax.swing.JTextArea();
        jScrollPane27 = new javax.swing.JScrollPane();
        i23 = new javax.swing.JTextArea();
        jScrollPane28 = new javax.swing.JScrollPane();
        i24 = new javax.swing.JTextArea();
        fasI = new javax.swing.JFrame();
        jTabbedPane10 = new javax.swing.JTabbedPane();
        jScrollPane29 = new javax.swing.JScrollPane();
        i25 = new javax.swing.JTextArea();
        jScrollPane30 = new javax.swing.JScrollPane();
        i26 = new javax.swing.JTextArea();
        jScrollPane31 = new javax.swing.JScrollPane();
        i27 = new javax.swing.JTextArea();
        harI = new javax.swing.JFrame();
        jTabbedPane11 = new javax.swing.JTabbedPane();
        jScrollPane32 = new javax.swing.JScrollPane();
        i28 = new javax.swing.JTextArea();
        jScrollPane33 = new javax.swing.JScrollPane();
        i29 = new javax.swing.JTextArea();
        jScrollPane34 = new javax.swing.JScrollPane();
        i30 = new javax.swing.JTextArea();
        incI = new javax.swing.JFrame();
        jTabbedPane12 = new javax.swing.JTabbedPane();
        jScrollPane35 = new javax.swing.JScrollPane();
        i31 = new javax.swing.JTextArea();
        jScrollPane36 = new javax.swing.JScrollPane();
        i32 = new javax.swing.JTextArea();
        jScrollPane37 = new javax.swing.JScrollPane();
        i33 = new javax.swing.JTextArea();
        kapI = new javax.swing.JFrame();
        jTabbedPane13 = new javax.swing.JTabbedPane();
        jScrollPane38 = new javax.swing.JScrollPane();
        i34 = new javax.swing.JTextArea();
        jScrollPane39 = new javax.swing.JScrollPane();
        i35 = new javax.swing.JTextArea();
        jScrollPane40 = new javax.swing.JScrollPane();
        i36 = new javax.swing.JTextArea();
        keiI = new javax.swing.JFrame();
        jTabbedPane14 = new javax.swing.JTabbedPane();
        jScrollPane41 = new javax.swing.JScrollPane();
        i37 = new javax.swing.JTextArea();
        jScrollPane42 = new javax.swing.JScrollPane();
        i38 = new javax.swing.JTextArea();
        jScrollPane43 = new javax.swing.JScrollPane();
        i39 = new javax.swing.JTextArea();
        kriI = new javax.swing.JFrame();
        jTabbedPane15 = new javax.swing.JTabbedPane();
        jScrollPane44 = new javax.swing.JScrollPane();
        i40 = new javax.swing.JTextArea();
        jScrollPane45 = new javax.swing.JScrollPane();
        i41 = new javax.swing.JTextArea();
        jScrollPane46 = new javax.swing.JScrollPane();
        i42 = new javax.swing.JTextArea();
        magI = new javax.swing.JFrame();
        jTabbedPane16 = new javax.swing.JTabbedPane();
        jScrollPane47 = new javax.swing.JScrollPane();
        i43 = new javax.swing.JTextArea();
        jScrollPane48 = new javax.swing.JScrollPane();
        i44 = new javax.swing.JTextArea();
        jScrollPane49 = new javax.swing.JScrollPane();
        i45 = new javax.swing.JTextArea();
        palI = new javax.swing.JFrame();
        jTabbedPane17 = new javax.swing.JTabbedPane();
        jScrollPane50 = new javax.swing.JScrollPane();
        i46 = new javax.swing.JTextArea();
        jScrollPane51 = new javax.swing.JScrollPane();
        i47 = new javax.swing.JTextArea();
        jScrollPane52 = new javax.swing.JScrollPane();
        i48 = new javax.swing.JTextArea();
        perI = new javax.swing.JFrame();
        jTabbedPane18 = new javax.swing.JTabbedPane();
        jScrollPane53 = new javax.swing.JScrollPane();
        i49 = new javax.swing.JTextArea();
        jScrollPane54 = new javax.swing.JScrollPane();
        i50 = new javax.swing.JTextArea();
        jScrollPane55 = new javax.swing.JScrollPane();
        i51 = new javax.swing.JTextArea();
        proI = new javax.swing.JFrame();
        jTabbedPane19 = new javax.swing.JTabbedPane();
        jScrollPane56 = new javax.swing.JScrollPane();
        i52 = new javax.swing.JTextArea();
        jScrollPane57 = new javax.swing.JScrollPane();
        i53 = new javax.swing.JTextArea();
        jScrollPane58 = new javax.swing.JScrollPane();
        i54 = new javax.swing.JTextArea();
        smiI = new javax.swing.JFrame();
        jTabbedPane20 = new javax.swing.JTabbedPane();
        jScrollPane59 = new javax.swing.JScrollPane();
        i55 = new javax.swing.JTextArea();
        jScrollPane60 = new javax.swing.JScrollPane();
        i56 = new javax.swing.JTextArea();
        jScrollPane61 = new javax.swing.JScrollPane();
        i57 = new javax.swing.JTextArea();
        twiI = new javax.swing.JFrame();
        jTabbedPane21 = new javax.swing.JTabbedPane();
        jScrollPane62 = new javax.swing.JScrollPane();
        i58 = new javax.swing.JTextArea();
        jScrollPane63 = new javax.swing.JScrollPane();
        i59 = new javax.swing.JTextArea();
        jScrollPane64 = new javax.swing.JScrollPane();
        i60 = new javax.swing.JTextArea();
        uniI = new javax.swing.JFrame();
        jTabbedPane22 = new javax.swing.JTabbedPane();
        jScrollPane65 = new javax.swing.JScrollPane();
        i61 = new javax.swing.JTextArea();
        jScrollPane66 = new javax.swing.JScrollPane();
        i62 = new javax.swing.JTextArea();
        jScrollPane67 = new javax.swing.JScrollPane();
        i63 = new javax.swing.JTextArea();
        abou = new javax.swing.JFrame();
        jScrollPane68 = new javax.swing.JScrollPane();
        i64 = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        res = new javax.swing.JTextArea();
        choice = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        r1 = new javax.swing.JTextField();
        r2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        key1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        r3 = new javax.swing.JTextField();
        range = new javax.swing.JRadioButton();
        che = new javax.swing.JRadioButton();
        info = new javax.swing.JButton();
        t2 = new javax.swing.JLabel();
        t1 = new javax.swing.JLabel();
        ch = new javax.swing.JLabel();
        countd = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem1 = new javax.swing.JMenuItem();

        buttonGroup1.add(no);
        no.setText("jRadioButton1");

        jTabbedPane2.setPreferredSize(new java.awt.Dimension(400, 300));

        i1.setEditable(false);
        i1.setColumns(20);
        i1.setLineWrap(true);
        i1.setRows(5);
        i1.setText("A positive integer of n digits is called an Armstrong number of order n (order is number of digits) if.\n");
        jScrollPane5.setViewportView(i1);

        jTabbedPane2.addTab("Definition", jScrollPane5);

        i2.setEditable(false);
        i2.setColumns(20);
        i2.setLineWrap(true);
        i2.setRows(5);
        i2.setText("n=Number of Digits\n\nabcd... = pow(a,n) + pow(b,n) + pow(c,n) + pow(d,n) + .... ");
        jScrollPane6.setViewportView(i2);

        jTabbedPane2.addTab("Logic", jScrollPane6);

        i3.setEditable(false);
        i3.setColumns(20);
        i3.setLineWrap(true);
        i3.setRows(5);
        i3.setText("Input : 153\nOutput : Yes\n153 is an Armstrong number.\nn=3\n1^3 + 5^3 + 3^3 = 153\n\nInput : 120\nOutput : No\n120 is not a Armstrong number.\nn=3\n1^3 + 2^3 + 0^3 = 9\n\nInput : 1253\nOutput : No\n1253 is not a Armstrong Number\nn=4\n1^4 + 2^4 + 5^4 + 3^4 = 723\n\nInput : 1634\nOutput : Yes\nn=4\n1^4 + 6^4 + 3^4 + 4^4 = 1634");
        jScrollPane7.setViewportView(i3);

        jTabbedPane2.addTab("Sample", jScrollPane7);

        javax.swing.GroupLayout armILayout = new javax.swing.GroupLayout(armI.getContentPane());
        armI.getContentPane().setLayout(armILayout);
        armILayout.setHorizontalGroup(
            armILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        armILayout.setVerticalGroup(
            armILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        i4.setEditable(false);
        i4.setColumns(20);
        i4.setLineWrap(true);
        i4.setRows(5);
        i4.setText("A number is called Automorphic number if and only if its square \nends in the same digits as the number itself.");
        jScrollPane8.setViewportView(i4);

        jTabbedPane3.addTab("Definition", jScrollPane8);

        i5.setEditable(false);
        i5.setColumns(20);
        i5.setLineWrap(true);
        i5.setRows(5);
        i5.setText("Number= n\n\ny=n*n\n\ny contains n in the end\n\n");
        jScrollPane9.setViewportView(i5);

        jTabbedPane3.addTab("Logic", jScrollPane9);

        i6.setEditable(false);
        i6.setColumns(20);
        i6.setLineWrap(true);
        i6.setRows(5);
        i6.setText("Input  : N = 76 \nOutput : Automorphic\nExplanation: \nAs 76*76 = 5776(ends with 76)\n\nInput  : N = 25\nOutput : Automorphic\nExplanation: \nAs 25*25 = 625(ends with 25)\n\nInput : N = 7\nOutput : Not Automorphic\nExplanation: \nAs 7*7 = 49(doesn't end with 7)");
        jScrollPane10.setViewportView(i6);

        jTabbedPane3.addTab("Sample", jScrollPane10);

        javax.swing.GroupLayout autoILayout = new javax.swing.GroupLayout(autoI.getContentPane());
        autoI.getContentPane().setLayout(autoILayout);
        autoILayout.setHorizontalGroup(
            autoILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        autoILayout.setVerticalGroup(
            autoILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i7.setEditable(false);
        i7.setColumns(20);
        i7.setLineWrap(true);
        i7.setRows(5);
        i7.setText("We shall call a positive integer that is neither increasing nor decreasing a “bouncy” number; for example, 155349. Clearly there cannot be any bouncy numbers below 100.");
        jScrollPane11.setViewportView(i7);

        jTabbedPane4.addTab("Definition", jScrollPane11);

        i8.setEditable(false);
        i8.setColumns(20);
        i8.setLineWrap(true);
        i8.setRows(5);
        i8.setText("Number = xyz\n\nx < y > z\n");
        jScrollPane12.setViewportView(i8);

        jTabbedPane4.addTab("Logic", jScrollPane12);

        i9.setEditable(false);
        i9.setColumns(20);
        i9.setLineWrap(true);
        i9.setRows(5);
        i9.setText("Input:-\n\t155349 \nOutput:-\n\t155349 is a Bouncy number \n\nSince:-\n 1<5<5>3<4<9");
        jScrollPane13.setViewportView(i9);

        jTabbedPane4.addTab("Sample", jScrollPane13);

        javax.swing.GroupLayout bounILayout = new javax.swing.GroupLayout(bounI.getContentPane());
        bounI.getContentPane().setLayout(bounILayout);
        bounILayout.setHorizontalGroup(
            bounILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        bounILayout.setVerticalGroup(
            bounILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i10.setEditable(false);
        i10.setColumns(20);
        i10.setLineWrap(true);
        i10.setRows(5);
        i10.setText("A number is called Disarium if sum of its digits powered with their respective positions is equal to the number itself.");
        jScrollPane14.setViewportView(i10);

        jTabbedPane5.addTab("Definition", jScrollPane14);

        i11.setEditable(false);
        i11.setColumns(20);
        i11.setLineWrap(true);
        i11.setRows(5);
        i11.setText("Number = xy..z\n\nxy..z = x^1 + y^2.....+ z^n\n\nn=number of digits\n");
        jScrollPane15.setViewportView(i11);

        jTabbedPane5.addTab("Logic", jScrollPane15);

        i12.setEditable(false);
        i12.setColumns(20);
        i12.setLineWrap(true);
        i12.setRows(5);
        i12.setText("Input   : 135\nOutput  : 135 is a Disarium number \n\nn=3\n1^1 + 3^2 + 5^3 = 135\n\nInput   : 89\nOutput  : 89 is a Disarium number \n\nn=2\n8^1+9^2 = 89\n\nInput   : 80\nOutput  : 80 is not a Disarium number \n\nn=0\n8^1 + 0^2 = 8");
        jScrollPane16.setViewportView(i12);

        jTabbedPane5.addTab("Sample", jScrollPane16);

        javax.swing.GroupLayout disILayout = new javax.swing.GroupLayout(disI.getContentPane());
        disI.getContentPane().setLayout(disILayout);
        disILayout.setHorizontalGroup(
            disILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        disILayout.setVerticalGroup(
            disILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i13.setEditable(false);
        i13.setColumns(20);
        i13.setLineWrap(true);
        i13.setRows(5);
        i13.setText(" Working from left-to-right,if no digit is exceeded by the digit to its \nright it is called a decreasing number");
        jScrollPane17.setViewportView(i13);

        jTabbedPane6.addTab("Definition", jScrollPane17);

        i14.setEditable(false);
        i14.setColumns(20);
        i14.setLineWrap(true);
        i14.setRows(5);
        i14.setText("Number = xyz\n\nx > y > z");
        jScrollPane18.setViewportView(i14);

        jTabbedPane6.addTab("Logic", jScrollPane18);

        i15.setEditable(false);
        i15.setColumns(20);
        i15.setLineWrap(true);
        i15.setRows(5);
        i15.setText("Input:-\n\t774410 \nOutput:-\n\t774410 is an Decreasing number \n\nSince:-\n\n7=7>4=4>1>0");
        jScrollPane19.setViewportView(i15);

        jTabbedPane6.addTab("Sample", jScrollPane19);

        javax.swing.GroupLayout decILayout = new javax.swing.GroupLayout(decI.getContentPane());
        decI.getContentPane().setLayout(decILayout);
        decILayout.setHorizontalGroup(
            decILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        decILayout.setVerticalGroup(
            decILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i16.setEditable(false);
        i16.setColumns(20);
        i16.setLineWrap(true);
        i16.setRows(5);
        i16.setText("A Duck number is a number which has zeroes present in it, but there should be no zero present in the beginning of the number.");
        jScrollPane20.setViewportView(i16);

        jTabbedPane7.addTab("Definition", jScrollPane20);

        i17.setEditable(false);
        i17.setColumns(20);
        i17.setLineWrap(true);
        i17.setRows(5);
        i17.setText("Number = xy..z\n\nif x is not 0 \nand if any digit of the number is 0\n\nit is a duck number\n");
        jScrollPane21.setViewportView(i17);

        jTabbedPane7.addTab("Logic", jScrollPane21);

        i18.setEditable(false);
        i18.setColumns(20);
        i18.setLineWrap(true);
        i18.setRows(5);
        i18.setText("Input : 707069\nOutput : 707069 is a duck number.\n\nExplanation: 707069 does not contains zeros at the beginning.\n\nInput : 02364\nOutput : 02364 is not a duck number.\n\nExplanation: in 02364 there is a zero at the beginning of the number.");
        jScrollPane22.setViewportView(i18);

        jTabbedPane7.addTab("Sample", jScrollPane22);

        javax.swing.GroupLayout ducILayout = new javax.swing.GroupLayout(ducI.getContentPane());
        ducI.getContentPane().setLayout(ducILayout);
        ducILayout.setHorizontalGroup(
            ducILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        ducILayout.setVerticalGroup(
            ducILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i22.setEditable(false);
        i22.setColumns(20);
        i22.setLineWrap(true);
        i22.setRows(5);
        i22.setText("An Evil number is a positive whole number which has even number of 1’s in its binary equivalent.");
        jScrollPane26.setViewportView(i22);

        jTabbedPane9.addTab("Definition", jScrollPane26);

        i23.setEditable(false);
        i23.setColumns(20);
        i23.setLineWrap(true);
        i23.setRows(5);
        i23.setText("Number = xy..z\n\nConvert the Number to its Binary Equivalent\nAnd Count the number of 1's present in it\n\nIf the number of 1's is evev ,it is a Duck Number.\n");
        jScrollPane27.setViewportView(i23);

        jTabbedPane9.addTab("Logic", jScrollPane27);

        i24.setEditable(false);
        i24.setColumns(20);
        i24.setLineWrap(true);
        i24.setRows(5);
        i24.setText("INPUT : 15\nOUTPUT : 15 is a Evil Number\nSINCE:\nBINARY EQUIVALENT : 1111\nNO. OF 1’s : 4(even)\n\nINPUT : 26\nOUTPUT : NOT AN EVIL NUMBER\nSINCE:\nBINARY EQUIVALENT : 11010\nNO. OF 1’s : 3(odd)");
        jScrollPane28.setViewportView(i24);

        jTabbedPane9.addTab("Sample", jScrollPane28);

        javax.swing.GroupLayout eviILayout = new javax.swing.GroupLayout(eviI.getContentPane());
        eviI.getContentPane().setLayout(eviILayout);
        eviILayout.setHorizontalGroup(
            eviILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        eviILayout.setVerticalGroup(
            eviILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i25.setEditable(false);
        i25.setColumns(20);
        i25.setLineWrap(true);
        i25.setRows(5);
        i25.setText("When a number( 3 digit or more) is multiplied by 2 and 3 ,and when both these products are concatenated with the original number all digits from 1 to 9 are present exactly once, regardless of the number of zeroes.");
        jScrollPane29.setViewportView(i25);

        jTabbedPane10.addTab("Definition", jScrollPane29);

        i26.setEditable(false);
        i26.setColumns(20);
        i26.setLineWrap(true);
        i26.setRows(5);
        i26.setText("Number xyz. \n\n1 x xyz = xyz\n2 x xyz = abc\n3 x xyz = def\n\nthen concadinate the three\ni.e. :- xyzabcdef\n\n if xyzabcdef contains number between 1 to 9,\nthen it is a Fascinating number");
        jScrollPane30.setViewportView(i26);

        jTabbedPane10.addTab("Logic", jScrollPane30);

        i27.setEditable(false);
        i27.setColumns(20);
        i27.setLineWrap(true);
        i27.setRows(5);
        i27.setText("Input:- 273\nOutput:- 273 is a Fascinating Number\nSince:-\n 1 x 273 = 273\n 2 x 273 = 546\n 3 x 273 = 819\n273546819 contains all the number between 1 to 9");
        jScrollPane31.setViewportView(i27);

        jTabbedPane10.addTab("Sample", jScrollPane31);

        javax.swing.GroupLayout fasILayout = new javax.swing.GroupLayout(fasI.getContentPane());
        fasI.getContentPane().setLayout(fasILayout);
        fasILayout.setHorizontalGroup(
            fasILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        fasILayout.setVerticalGroup(
            fasILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i28.setEditable(false);
        i28.setColumns(20);
        i28.setLineWrap(true);
        i28.setRows(5);
        i28.setText("Any positive integer which is divisible by the sum of its digits is a Harshad Number or Niven Number.");
        jScrollPane32.setViewportView(i28);

        jTabbedPane11.addTab("Definition", jScrollPane32);

        i29.setEditable(false);
        i29.setColumns(20);
        i29.setLineWrap(true);
        i29.setRows(5);
        i29.setText("Number = xy..z\n\nSay a=x+y+...+z\n\nIf a is divisble by xy..z\n then it is a Harshad or Niven number else Not");
        jScrollPane33.setViewportView(i29);

        jTabbedPane11.addTab("Logic", jScrollPane33);

        i30.setEditable(false);
        i30.setColumns(20);
        i30.setLineWrap(true);
        i30.setRows(5);
        i30.setText("Input:- 2\nOutput:- 2 is a Harshad or niven number\nSince:- 2 is divisible by 2\n\nInput:- 16\nOutput:- 16 is not a Harshad or niven number\nSince:- 7(6+1) No.(16 is not divisible by 7)\n\nInput:- 200\nOutput:- 200 is a Harshad or niven number\nSince:- 2(2+0+0) Yes.(200 is divisible by 2)");
        jScrollPane34.setViewportView(i30);

        jTabbedPane11.addTab("Sample", jScrollPane34);

        javax.swing.GroupLayout harILayout = new javax.swing.GroupLayout(harI.getContentPane());
        harI.getContentPane().setLayout(harILayout);
        harILayout.setHorizontalGroup(
            harILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        harILayout.setVerticalGroup(
            harILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i31.setEditable(false);
        i31.setColumns(20);
        i31.setLineWrap(true);
        i31.setRows(5);
        i31.setText(" Working from left-to-right,if no digit is exceeded by the digit to its \nleft it is called a decreasing number");
        jScrollPane35.setViewportView(i31);

        jTabbedPane12.addTab("Definition", jScrollPane35);

        i32.setEditable(false);
        i32.setColumns(20);
        i32.setLineWrap(true);
        i32.setRows(5);
        i32.setText("Number = xyz\n\nx < y < z");
        jScrollPane36.setViewportView(i32);

        jTabbedPane12.addTab("Logic", jScrollPane36);

        i33.setEditable(false);
        i33.setColumns(20);
        i33.setLineWrap(true);
        i33.setRows(5);
        i33.setText("Input:- 22344\nOutput:- 22344 is a Increasing Number\nSince:- 2=2<3<4=4");
        jScrollPane37.setViewportView(i33);

        jTabbedPane12.addTab("Sample", jScrollPane37);

        javax.swing.GroupLayout incILayout = new javax.swing.GroupLayout(incI.getContentPane());
        incI.getContentPane().setLayout(incILayout);
        incILayout.setHorizontalGroup(
            incILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        incILayout.setVerticalGroup(
            incILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i34.setEditable(false);
        i34.setColumns(20);
        i34.setLineWrap(true);
        i34.setRows(5);
        i34.setText("A Kaprekar number is a number whose square when divided into two parts and such that sum of parts is equal to the original number and none of the parts has value 0.");
        jScrollPane38.setViewportView(i34);

        jTabbedPane13.addTab("Definition", jScrollPane38);

        i35.setEditable(false);
        i35.setColumns(20);
        i35.setLineWrap(true);
        i35.setRows(5);
        i35.setText("Number= n\n\nLet A be the square of the number n .\nDivide the number A into equal half and add them,let the sum be C\n\nif C is same as the number n ,it is a Kaprekar Number\nelse Not");
        jScrollPane39.setViewportView(i35);

        jTabbedPane13.addTab("Logic", jScrollPane39);

        i36.setEditable(false);
        i36.setColumns(20);
        i36.setLineWrap(true);
        i36.setRows(5);
        i36.setText("Input :  45  \nOutput : 45 is a Kaprekar Number\nExplanation : 45^2 = 2025 and 20 + 25 is 45\n \nInput : 13\nOutput : 13 is a Kaprekar Number\nExplanation : 13^2 = 169. Neither 16 + 9 nor 1 + 69 is equal to 13\n\nInput  : 10 \nOutput : 10 is not a Kaprekar Number\nExplanation:  10^2 = 100. It is not a Kaprekar number even if\nsum of 100 + 0 is 100. This is because of the condition that \nnone of the parts should have value 0.");
        jScrollPane40.setViewportView(i36);

        jTabbedPane13.addTab("Sample", jScrollPane40);

        javax.swing.GroupLayout kapILayout = new javax.swing.GroupLayout(kapI.getContentPane());
        kapI.getContentPane().setLayout(kapILayout);
        kapILayout.setHorizontalGroup(
            kapILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane13, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        kapILayout.setVerticalGroup(
            kapILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane13, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i37.setEditable(false);
        i37.setColumns(20);
        i37.setLineWrap(true);
        i37.setRows(5);
        i37.setText("A n digit number x is called Keith number if it appears in a special sequence (defined below) generated using its digits. The special sequence has first n terms as digits of x and other terms are recursively evaluated as sum of previous n terms.");
        jScrollPane41.setViewportView(i37);

        jTabbedPane14.addTab("Definition", jScrollPane41);

        i38.setEditable(false);
        i38.setColumns(20);
        i38.setLineWrap(true);
        i38.setRows(5);
        i38.setText("Number = xy..z\n\nThe digits of the number acts as the starting of the series ,like x,y,..,z and they add up to form the next number. Keep on adding like fibonacci series .\n\nIf the number exist within the series, it is a Keith Number \nelse NOT");
        jScrollPane42.setViewportView(i38);

        jTabbedPane14.addTab("Logic", jScrollPane42);

        i39.setEditable(false);
        i39.setColumns(20);
        i39.setLineWrap(true);
        i39.setRows(5);
        i39.setText("Input : x = 197\nOutput : Yes\n197 has 3 digits, so n = 3\nThe number is Keith because it appears in the special\nsequence that has first three terms as 1, 9, 7 and \nremaining terms evaluated using sum of previous 3 terms.\n1, 9, 7, 17, 33, 57, 107, 197, .....\n\nInput : x = 12\nOutput : No\nThe number is not Keith because it doesn't appear in\nthe special sequence generated using its digits.\n1, 2, 3, 5, 8, 13, 21, .....\n\nInput : x = 14\nOutput : Yes\n14 is a Keith number since it appears in the sequence,\n1, 4, 5, 9, 14, ...");
        jScrollPane43.setViewportView(i39);

        jTabbedPane14.addTab("Sample", jScrollPane43);

        javax.swing.GroupLayout keiILayout = new javax.swing.GroupLayout(keiI.getContentPane());
        keiI.getContentPane().setLayout(keiILayout);
        keiILayout.setHorizontalGroup(
            keiILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        keiILayout.setVerticalGroup(
            keiILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i40.setEditable(false);
        i40.setColumns(20);
        i40.setLineWrap(true);
        i40.setRows(5);
        i40.setText("A Krishnamurthy number is a number whose sum of the factorial of digits is equal to the number itself.");
        jScrollPane44.setViewportView(i40);

        jTabbedPane15.addTab("Definition", jScrollPane44);

        i41.setEditable(false);
        i41.setColumns(20);
        i41.setLineWrap(true);
        i41.setRows(5);
        i41.setText("Number = xy..z\n\nLet sum be\na= x!+y!+..+z!\n\nIf a is equal to xy..z\n then it is a Krishnamurty Number");
        jScrollPane45.setViewportView(i41);

        jTabbedPane15.addTab("Logic", jScrollPane45);

        i42.setEditable(false);
        i42.setColumns(20);
        i42.setLineWrap(true);
        i42.setRows(5);
        i42.setText("Input : 145\nOutput : 145 is a Krishnamurty Number\nExplanation: 1! + 4! + 5! = \n1 + 24 + 120 = 145, which is equal to input,\nhence YES.\n\nInput : 235\nOutput : 235 is not a Krishnamurty Number\nExplanation: 2! + 3! + 5! = \n2 + 6 + 120 = 128, which is not equal to input, \nhence NO.");
        jScrollPane46.setViewportView(i42);

        jTabbedPane15.addTab("Sample", jScrollPane46);

        javax.swing.GroupLayout kriILayout = new javax.swing.GroupLayout(kriI.getContentPane());
        kriI.getContentPane().setLayout(kriILayout);
        kriILayout.setHorizontalGroup(
            kriILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane15, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        kriILayout.setVerticalGroup(
            kriILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane15, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i43.setEditable(false);
        i43.setColumns(20);
        i43.setLineWrap(true);
        i43.setRows(5);
        i43.setText("A number is said to be a magic number, if the sum of its digits are  calculated till a single digit recursively by adding the sum of the digits after every addition. If the single digit comes out to be 1,then the number is a magic number.");
        jScrollPane47.setViewportView(i43);

        jTabbedPane16.addTab("Definition", jScrollPane47);

        i44.setEditable(false);
        i44.setColumns(20);
        i44.setLineWrap(true);
        i44.setRows(5);
        i44.setText("Number = xy..z\n\nThe ultimate sum of the digits should come as a single digit and if the digit is 1 ,it is a Magic number\n\nsuppose x+y+..z is a number like a\nif a is a number greater than 9 , then again we have to find the sum of the digits\n\nIf the sum is a single digit number ,and is 1 ,it is a Magic Number\nelse NOT.\n");
        jScrollPane48.setViewportView(i44);

        jTabbedPane16.addTab("Logic", jScrollPane48);

        i45.setEditable(false);
        i45.setColumns(20);
        i45.setLineWrap(true);
        i45.setRows(5);
        i45.setText("Input: 50113\nOutput: 50113 is a Magic Number\nExplanation: 5+0+1+1+3=10 ; 1+0=1\n\nInput: 12345\nOutput: 12345 is not a Magic Number\nExplanation: 1+2+3+4+5=15 ; 1+5=6");
        jScrollPane49.setViewportView(i45);

        jTabbedPane16.addTab("Sample", jScrollPane49);

        javax.swing.GroupLayout magILayout = new javax.swing.GroupLayout(magI.getContentPane());
        magI.getContentPane().setLayout(magILayout);
        magILayout.setHorizontalGroup(
            magILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane16, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        magILayout.setVerticalGroup(
            magILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane16, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i46.setEditable(false);
        i46.setColumns(20);
        i46.setLineWrap(true);
        i46.setRows(5);
        i46.setText("A palindrome number is a number that is same after reversing the number.");
        jScrollPane50.setViewportView(i46);

        jTabbedPane17.addTab("Definition", jScrollPane50);

        i47.setEditable(false);
        i47.setColumns(20);
        i47.setLineWrap(true);
        i47.setRows(5);
        i47.setText("Number= xy..z\n\nReverse the number ,say ab..c\n\nand the numbers are similar, then it is a \nPallindrome Number\nelse NOT  ");
        jScrollPane51.setViewportView(i47);

        jTabbedPane17.addTab("Logic", jScrollPane51);

        i48.setEditable(false);
        i48.setColumns(20);
        i48.setLineWrap(true);
        i48.setRows(5);
        i48.setText("Input: 151\nOutput: 151 is a Pallindrome Number\nExplanation: 151 on reversing is 151 which is the same\n\nInput: 1243\nOutput: 1243 is not a Pallindrome Number\n\nExplanation: 1243 on reversing is 3421 which is not the same");
        jScrollPane52.setViewportView(i48);

        jTabbedPane17.addTab("Sample", jScrollPane52);

        javax.swing.GroupLayout palILayout = new javax.swing.GroupLayout(palI.getContentPane());
        palI.getContentPane().setLayout(palILayout);
        palILayout.setHorizontalGroup(
            palILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane17, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        palILayout.setVerticalGroup(
            palILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane17, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i49.setEditable(false);
        i49.setColumns(20);
        i49.setLineWrap(true);
        i49.setRows(5);
        i49.setText("A number is a perfect number if is equal to sum of its proper divisors, that is, sum of its positive divisors excluding the number itself.");
        jScrollPane53.setViewportView(i49);

        jTabbedPane18.addTab("Definition", jScrollPane53);

        i50.setEditable(false);
        i50.setColumns(20);
        i50.setLineWrap(true);
        i50.setRows(5);
        i50.setText("Number = n\n\nFind the Divisors of the number n and add them ,\nlet the result be a\n\nif a and n are the same number\nIt is a Perfect Number\nelse NOT");
        jScrollPane54.setViewportView(i50);

        jTabbedPane18.addTab("Logic", jScrollPane54);

        i51.setEditable(false);
        i51.setColumns(20);
        i51.setLineWrap(true);
        i51.setRows(5);
        i51.setText("Input: 15\nOutput: 15 is not a Perfect Number\nExplanation: Divisors of 15 are 1, 3 and 5. Sum of divisors is 9 which is not equal to 15.\n\nInput: 6\nOutput: 6 is a Perfect Number\nExplanation: Divisors of 6 are 1, 2 and 3. Sum of divisors is 6.");
        jScrollPane55.setViewportView(i51);

        jTabbedPane18.addTab("Sample", jScrollPane55);

        javax.swing.GroupLayout perILayout = new javax.swing.GroupLayout(perI.getContentPane());
        perI.getContentPane().setLayout(perILayout);
        perILayout.setHorizontalGroup(
            perILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane18, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        perILayout.setVerticalGroup(
            perILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane18, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i52.setEditable(false);
        i52.setColumns(20);
        i52.setLineWrap(true);
        i52.setRows(5);
        i52.setText("The numbers that can be arranged to form a rectangle are called Pronic Numbers (also known as Rectangular numbers).");
        jScrollPane56.setViewportView(i52);

        jTabbedPane19.addTab("Definition", jScrollPane56);

        i53.setEditable(false);
        i53.setColumns(20);
        i53.setLineWrap(true);
        i53.setRows(5);
        i53.setText("Number = n\nIf the product of two consecutive number within the number n is similar to the number n,\nit is a Pronic number\nelse NOT");
        jScrollPane57.setViewportView(i53);

        jTabbedPane19.addTab("Logic", jScrollPane57);

        i54.setEditable(false);
        i54.setColumns(20);
        i54.setLineWrap(true);
        i54.setRows(5);
        i54.setText("Input  : 6\nOutput : 6 is a Pronic Number\nExplanation: 6 = 2 * 3 i.e 6 is a product\nof two consecutive integers 2 and 3.\n\nInput :56\nOutput :56 is a Pronic Number\nExplanation: 56 = 7 * 8 i.e 56 is a product \nof two consecutive integers 7 and 8. \n\nInput  : 8\nOutput : 8 is not a Pronic Number\nExplanation: 8 = 2 * 4 i.e 8 is a product of \n2 and 4 which are not consecutive integers.");
        jScrollPane58.setViewportView(i54);

        jTabbedPane19.addTab("Sample", jScrollPane58);

        javax.swing.GroupLayout proILayout = new javax.swing.GroupLayout(proI.getContentPane());
        proI.getContentPane().setLayout(proILayout);
        proILayout.setHorizontalGroup(
            proILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        proILayout.setVerticalGroup(
            proILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i55.setEditable(false);
        i55.setColumns(20);
        i55.setLineWrap(true);
        i55.setRows(5);
        i55.setText("A Smith Number is a composite number whose sum of digits is equal to the sum of digits in its prime factorization.");
        jScrollPane59.setViewportView(i55);

        jTabbedPane20.addTab("Definition", jScrollPane59);

        i56.setEditable(false);
        i56.setColumns(20);
        i56.setLineWrap(true);
        i56.setRows(5);
        i56.setText("Number = n\n\nFind the prime factor of the number and find the sum of the digits of the numbers ,say A\n\nAnd also find the sum of the digits of the number n ,say B\n\nif A+B is equal to n, it is Smith number\nelse NOT");
        jScrollPane60.setViewportView(i56);

        jTabbedPane20.addTab("Logic", jScrollPane60);

        i57.setEditable(false);
        i57.setColumns(20);
        i57.setLineWrap(true);
        i57.setRows(5);
        i57.setText("Input  : n = 4\nOutput : Yes\nPrime factorization = 2, 2  and 2 + 2 = 4\nTherefore, 4 is a smith number\n\nInput  : n = 6\nOutput : No\nPrime factorization = 2, 3  and 2 + 3 is\nnot 6. Therefore, 6 is not a smith number\n\nInput   : n = 666\nOutput  : Yes\nPrime factorization = 2, 3, 3, 37 and\n2 + 3 + 3 + (3 + 7) = 6 + 6 + 6 = 18\nTherefore, 666 is a smith number\n\nInput   : n = 13\nOutput  : No\nPrime factorization = 13 and 13 = 13,\nBut 13 is not a smith number as it is not\na composite number");
        jScrollPane61.setViewportView(i57);

        jTabbedPane20.addTab("Sample", jScrollPane61);

        javax.swing.GroupLayout smiILayout = new javax.swing.GroupLayout(smiI.getContentPane());
        smiI.getContentPane().setLayout(smiILayout);
        smiILayout.setHorizontalGroup(
            smiILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane20, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        smiILayout.setVerticalGroup(
            smiILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane20, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i58.setEditable(false);
        i58.setColumns(20);
        i58.setLineWrap(true);
        i58.setRows(5);
        i58.setText("A Twin prime are those numbers which are prime and having a difference of two ( 2 ) between the two prime numbers. In other words, a twin prime is a prime that has a prime gap of two.");
        jScrollPane62.setViewportView(i58);

        jTabbedPane21.addTab("Definition", jScrollPane62);

        i59.setEditable(false);
        i59.setColumns(20);
        i59.setLineWrap(true);
        i59.setRows(5);
        i59.setText("If a prime number is found and another prime number is found ,and their difference is 2, It is a Twin prime pair \nelse NOT\n\nNOTE :-\n   It only works/runs within a range ");
        jScrollPane63.setViewportView(i59);

        jTabbedPane21.addTab("Logic", jScrollPane63);

        i60.setEditable(false);
        i60.setColumns(20);
        i60.setLineWrap(true);
        i60.setRows(5);
        i60.setText("Example :-\n(3, 5)\n(5, 7)\n(11, 13) \n(59, 61)\n(71, 73)\n(101, 103) \n(107, 109)");
        jScrollPane64.setViewportView(i60);

        jTabbedPane21.addTab("Sample", jScrollPane64);

        javax.swing.GroupLayout twiILayout = new javax.swing.GroupLayout(twiI.getContentPane());
        twiI.getContentPane().setLayout(twiILayout);
        twiILayout.setHorizontalGroup(
            twiILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane21, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        twiILayout.setVerticalGroup(
            twiILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane21, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i61.setEditable(false);
        i61.setColumns(20);
        i61.setLineWrap(true);
        i61.setRows(5);
        i61.setText("A Unique number is a positive integer (without leading zeros) with no duplicate digits.");
        jScrollPane65.setViewportView(i61);

        jTabbedPane22.addTab("Definition", jScrollPane65);

        i62.setEditable(false);
        i62.setColumns(20);
        i62.setLineWrap(true);
        i62.setRows(5);
        i62.setText("Number = n\n\nThe number should not contain any repeated digits and no leading 0's");
        jScrollPane66.setViewportView(i62);

        jTabbedPane22.addTab("Logic", jScrollPane66);

        i63.setEditable(false);
        i63.setColumns(20);
        i63.setLineWrap(true);
        i63.setRows(5);
        i63.setText("Input:- 7\nOutput:- 7 is a Unique Number\n\nInput:- 133\nOutput:- 133 is not a Unique Number\n\nInput:- 214\nOutput:- 214 is a Unique Number ");
        jScrollPane67.setViewportView(i63);

        jTabbedPane22.addTab("Sample", jScrollPane67);

        javax.swing.GroupLayout uniILayout = new javax.swing.GroupLayout(uniI.getContentPane());
        uniI.getContentPane().setLayout(uniILayout);
        uniILayout.setHorizontalGroup(
            uniILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane22, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        uniILayout.setVerticalGroup(
            uniILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane22, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        i64.setEditable(false);
        i64.setColumns(20);
        i64.setFont(new java.awt.Font("Tempus Sans ITC", 3, 13)); // NOI18N
        i64.setLineWrap(true);
        i64.setRows(5);
        i64.setText("This is developed to help with the different kind of \nnumbers present in the programming world. it will you   to check the specific type of number present in within a range or to check wether it is that number or not.\n\n\nMade by :- Soumyadeep Shome\nSupported by :- Anisoft Computer Academy\nContact:- soumyadeepshome99@gmail.com\n\nVersion  :-  1.0\n");
        i64.setPreferredSize(new java.awt.Dimension(226, 130));
        jScrollPane68.setViewportView(i64);

        javax.swing.GroupLayout abouLayout = new javax.swing.GroupLayout(abou.getContentPane());
        abou.getContentPane().setLayout(abouLayout);
        abouLayout.setHorizontalGroup(
            abouLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane68, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        abouLayout.setVerticalGroup(
            abouLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane68, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Know Your Number");

        res.setColumns(20);
        res.setRows(5);
        jScrollPane1.setViewportView(res);

        choice.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "None", "Armstrong", "Automorphic", "Bouncy", "Decreasing", "Disarium", "Duck", "Evil", "Fascinating", "Harshad or Niven", "Increasing", "Kaprekar", "Keith", "Krishnamurthy", "Magic", "Pallindrome", "Perfect", "Pronic", "Smith", "Twin Prime", "Unique" }));
        choice.setName(""); // NOI18N
        choice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                choiceActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Know Your Number");

        jTextField1.setText("jTextField1");
        jTextField1.setUI(null);

        r1.setText("0");

        r2.setText("100");

        jLabel3.setText("To");

        key1.setText("Generate");
        key1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                key1ActionPerformed(evt);
            }
        });

        jLabel2.setText("Output:-");

        jLabel5.setText("Select A Number ");

        r3.setText("0");

        buttonGroup1.add(range);
        range.setText("Range");
        range.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rangeActionPerformed(evt);
            }
        });

        buttonGroup1.add(che);
        che.setText("Checking");
        che.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cheActionPerformed(evt);
            }
        });

        info.setText("(i)");
        info.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                infoActionPerformed(evt);
            }
        });

        countd.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        countd.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        jMenu1.setText("File");

        jMenuItem5.setText("About");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuItem2.setText("Clear");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);
        jMenu1.add(jSeparator1);

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Quit");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(choice, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(info))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addComponent(r3, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(range)
                                            .addComponent(r1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(r2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(che))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(countd, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(key1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(info, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(t1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ch, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(t2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(countd, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(choice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(range)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(r1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel3))
                                    .addComponent(r2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 17, Short.MAX_VALUE)
                        .addComponent(che)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(r3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)))
                .addComponent(key1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    int a=0;
    int z=0;
    private void choiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_choiceActionPerformed
        visof();
    }//GEN-LAST:event_choiceActionPerformed
    
    void vison()
    {
        t1.setText("Number of");
        t2.setText("No.'s =");
    }
    void visof()
    {
        t1.setText("");
        t2.setText("");
        ch.setText("");
        countd.setText("");
    }
    
    private void key1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_key1ActionPerformed
        
        String s= choice.getSelectedItem().toString();
        int t12=Integer.parseInt(r1.getText());
        int t22=Integer.parseInt(r2.getText());
        int t3=Integer.parseInt(r3.getText());
        
        if(a==0 || s.equalsIgnoreCase("none"))
        {
            JOptionPane.showMessageDialog(this,"Enter a Choice");
            res.setText("");
        }
        res.setText("");
        
        if(s.equalsIgnoreCase("Armstrong"))
        {
           if(a==1)
            {    
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    ArmStrong(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
           }
           else if(a==2)
                ArmStrong(t3);
        }
        else if(s.equalsIgnoreCase("Automorphic"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Automorphic(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Automorphic(t3);
        }
        else if(s.equalsIgnoreCase("Bouncy"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Bouncy(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Bouncy(t3);
        }
        else if(s.equalsIgnoreCase("Decreasing"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Decreasing(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Decreasing(t3);
        }
        else if(s.equalsIgnoreCase("Disarium"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Disarium(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Disarium(t3);   
        }
        
        else if(s.equalsIgnoreCase("Duck"))
        {
            if(a==1)
            {   
                z=0;
                if(t12==0)
                {
                    res.append(t12+"\n");
                    t12++;
                    z++;
                }
                
                for(int i=t12;i<=t22;i++)
                {
                    Duck(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Duck(t3);
        }
        else if(s.equalsIgnoreCase("evil"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Evil(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Evil(t3);
        }
        
        else if(s.equalsIgnoreCase("Fascinating"))
        {
            if(a==1)
            {    
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Fascinating(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Fascinating(t3);
        }
        else if(s.equalsIgnoreCase("Harshad or Niven"))
        {
            if(a==1)
            {   
                if(t12==0)
                {
                    t12++;
                }
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Harshad(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
            {
                Harshad(t3);
            }
        }
        else if(s.equalsIgnoreCase("Increasing"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Increasing(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Increasing(t3);   
        }
        else if(s.equalsIgnoreCase("Kaprekar"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Kaprekar(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Kaprekar(t3);
        }
        else if(s.equalsIgnoreCase("Keith"))
        {
            if(a==1)
            {
                if(t12==0)
                    t12+=2;
                if(t12==1)
                    t12++;
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Keith(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
            {
                Keith(t3);
            }          
        }
        else if(s.equalsIgnoreCase("Krishnamurthy"))
        {
            if(a==1)
            {   
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    krishnamurthy(i);
                }   
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                krishnamurthy(t3);
        }        
        else if(s.equalsIgnoreCase("Magic"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Magic(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Magic(t3);   
        }
        else if(s.equalsIgnoreCase("Pallindrome"))
        {
            if(a==1)
            {   
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Pallindrome(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }else if(a==2)
                Pallindrome(t3);
        }
        else if(s.equalsIgnoreCase("Perfect"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Perfect(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Perfect(t3);   
        }
        else if(s.equalsIgnoreCase("Pronic"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Pronic(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Pronic(t3);
        }
        
        else if(s.equalsIgnoreCase("Smith"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Smith(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }
            else if(a==2)
                Smith(t3);
        }
        else if(s.equalsIgnoreCase("Twin Prime"))
        {
            if(a==1)
                Twin_Prime();
            else if(a==2)
                JOptionPane.showMessageDialog(this,"Works Only With a Range");    
        }
        else if(s.equalsIgnoreCase("Unique"))
        {
            if(a==1)
            {
                z=0;
                for(int i=t12;i<=t22;i++)
                {
                    Unique(i);
                }
                vison();
                countd.setText(z+" "); 
                ch.setText(s);
            }            
            else if(a==2)
                Unique(t3);                
        }
    }//GEN-LAST:event_key1ActionPerformed

    private void rangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rangeActionPerformed
        a=1;
    }//GEN-LAST:event_rangeActionPerformed

    private void cheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cheActionPerformed
        a=2;
       visof();
    }//GEN-LAST:event_cheActionPerformed
    
    private void infoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_infoActionPerformed
        String s= choice.getSelectedItem().toString();
       if(s.equalsIgnoreCase("none"))
        {
            JOptionPane.showMessageDialog(this,"Enter a Choice");
        }
        else
        {
            if(s.equalsIgnoreCase("Armstrong"))
            {
                armI.setSize(405,300);
                armI.setVisible(true);          
            }
            else if(s.equalsIgnoreCase("Automorphic"))
            {
                autoI.setSize(405,300);
                autoI.setVisible(true); 
            }
            else if(s.equalsIgnoreCase("Bouncy"))
            {
                bounI.setSize(405,300);
                bounI.setVisible(true); 
            } 
            else if(s.equalsIgnoreCase("Decreasing"))
            {
                decI.setSize(405,300);
                decI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Disarium"))
            {
                disI.setSize(405,300);
                disI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Duck"))
            {
                ducI.setSize(405,300);
                ducI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("evil"))
            {
                eviI.setSize(405,300);
                eviI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Fascinating"))
            {
                fasI.setSize(405,300);
                fasI.setVisible(true);
            }        
            else if(s.equalsIgnoreCase("Harshad or Niven"))
            {
                harI.setSize(405,300);
                harI.setVisible(true);
            }
           
            else if(s.equalsIgnoreCase("Increasing"))
            {
                incI.setSize(405,300);
                incI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Pallindrome"))
            {
                palI.setSize(405,300);
                palI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Krishnamurthy"))
            {
                kriI.setSize(405,300);
                kriI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Kaprekar"))
            {
                kapI.setSize(405,300);
                kapI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Keith"))
            {
                keiI.setSize(405,300);
                keiI.setVisible(true);
            }

            else if(s.equalsIgnoreCase("Magic"))
            {
                magI.setSize(405,300);
                magI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Perfect"))
            {
                perI.setSize(405,300);
                perI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Pronic"))
            {
                proI.setSize(405,300);
                proI.setVisible(true);
            }
            
            else if(s.equalsIgnoreCase("Smith"))
            {
                smiI.setSize(405,300);
                smiI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Twin Prime"))
            {
                twiI.setSize(405,300);
                twiI.setVisible(true);
            }
            else if(s.equalsIgnoreCase("Unique"))
            {
                uniI.setSize(405,300);
                uniI.setVisible(true);
            }
        }
    }//GEN-LAST:event_infoActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
       System.exit(0);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        res.setText("");
        visof();
        no.setSelected(true);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        abou.setSize(400,300);
        abou.setVisible(true);
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    boolean isDecreasing(int n) //Function to check whether a number is Decreasing
    {
        String s = Integer.toString(n);
        char ch2;
        int f = 0;
        for(int i=0; i<s.length()-1; i++)
        {
            ch2 = s.charAt(i);
            if(ch2<s.charAt(i+1))// If any digit is less than next digit then we have to stop checking
            {
                f = 1;
                break;
            }
        }
        return f != 1;
    }
    boolean isIncreasing(int n) //Function to check whether a number is Increasing
    {
        String s = Integer.toString(n);
        char ch3;
        int f = 0;
        for(int i=0; i<s.length()-1; i++)
        {
            ch3 = s.charAt(i);
            if(ch3>s.charAt(i+1))// If any digit is more than next digit then we have to stop checking
            {
                f = 1;
                break;
            }
        }
        return f != 1;
    }
    boolean isPrime(int n) //funton for checking prime
    {
            int count=0;
            for(int i=1; i<=n; i++)
                {
                    if(n%i == 0)
                        count++;
                }
        return count == 2;
        }
    
    void ArmStrong(int i)
    {
            int d=0;
            int n=i;
            while(n>0)
            {
                d++;
                n=n/10;
            }
            int c=0;
            n=i;
            while(n>0)
            {
                int y=n%10;
                c=c+(int)Math.pow(y,d);
                n=n/10;
            }
            if(c==i)
            {
                if(a==1)
                {   
                    res.append(c+"\n");
                    z++;
                }
                else if(a==2)
                    res.setText(i+" is an Armstrong number. \n");
            }
            else if(a==2)
                res.setText(i+" is not an Armstrong number. \n");
        
    }
    void Automorphic(int n)
    {
        int sq = n*n; // Finding the square
        String num = Integer.toString(n); // Converting the number to String
        String square = Integer.toString(sq); // Converting the square to String
        if(square.endsWith(num)) 
        {
            if(a==1)
            {
                res.append(n+"\n");
                z++;
            }
            else if(a==2)
            {    
                res.setText(n+" is a Automorphic Number");
            }
        }
        else if(a==2)
            res.setText(n+" is not a Automorphic Number");
    }
    void Bouncy(int n)
    {
        if(isIncreasing(n)==false || isDecreasing(n)==false)
        {    
            if(a==1)
            {
                res.append(n + "\n");
                z++;
            }else if(a==2)
                res.setText(n+" is a Bouncy Number");
        }
        else if(a==2)
            res.setText(n+" is not a Bouncy Number");
    }
    void Decreasing(int n)
    {
        if(isDecreasing(n)==true)
        {
            if(a==1)
            {    res.append(n + "\n");
            z++;
                }else if(a==2)
                res.setText(n+" is a Decreasing Number");
        }
        else if(a==2)
        {
            res.setText(n+" is not a Decreasing Number");
        }
    }
    void Disarium(int n)
    {
        int copy = n, d = 0, sum = 0;
        String s = Integer.toString(n); //converting the number into a String
        int len = s.length(); //finding the length of the number i.e. no.of digits

        while(copy>0)
        {
            d = copy % 10; //extracting the last digit
            sum = sum + (int)Math.pow(d,len);
            len--;
            copy = copy / 10;
        }

        if(sum == n)
        {
            if(a==1)
            {
                res.append(n+"\n");
                z++;
            }else if(a==2)
                res.setText(n+" is a Disarium Number");
        }
        else if(a==2)
            res.setText(n+" is not a Disarium Number");
    }
    void Duck(int n)
    {
        if(n==0 && a==2)
            res.setText(n+" is a Duck Number");
        else
        {
            String s=Integer.toString(n);
            int l=s.length(); //finding the length (number of digit) of the number
            int c=0; //variable for counting number of zero digits
            char ch3;
            for(int i=1;i<l;i++)
            {
                ch3=s.charAt(i); //extracting each digit and checking whether it is a '0' or not
                if(ch3=='0')
                    c++;
            }
            char f=s.charAt(0); //taking out the first digit of the inputted number
            if(c>0 && f!='0')
            {
                if(a==1)
                {
                    res.append(n+"\n");
                    z++;
                }else if(a==2)
                    res.setText(n+" is a Duck Number");
            }
            else if(a==2)
                res.setText(n+" is not a Duck Number");
        }
    }
    void Evil(int i)
    {
          
            int n=i,r;
            String s="";
            char dig[]={'0','1'};  
            while(n>0)
            {
                r=n%2; //finding remainder by dividing the number by 2
                s=dig[r]+s; //adding the remainder to the result and reversing at the same time
                n=n/2;
            }
            int c = 0, l = s.length();
            char ch1;
            for(int j=0; j<l; j++)
            {
                ch1=s.charAt(j);
                if(ch1=='1')
                {
                    c++;
                }
            }
            
            if(c%2==0)
            {
                if(a==1)
                {
                    res.append(i+"\n");
                z++;
                }else if(a==2)
                    res.setText(i+" is Evil Number.");
            }
            else if(a==2)
                res.setText(i+" is not an Evil Number.");
    }
    void Fascinating(int i)
    {   
            String p = Integer.toString(i);
            String s = Integer.toString(i*1) + Integer.toString(i*2) + Integer.toString(i*3);
            int A[] = {0,0,0,0,0,0,0,0,0,0};
            int j, flag = 0;
            char ch1;
            for(j=0; j<s.length(); j++)
            {
                ch1 = s.charAt(j);
                A[ch1-48]++;
            }
            for(j=1; j<10; j++)
            {
                if(A[j]!=1)
                {
                    flag = 1;
                    break;
                }
            }
            if(flag==0)
            {
                if(a==1)
                {
                    res.append(i+"\n");
                z++;
                }else if(a==2)
                    res.setText(i+" is Fascinating number");
            }
            else if(a==2)
                res.setText(i+" is not a Fascinating Number");
    }
    void Harshad(int i)
    {
        if(i==0 && a==2)
            res.setText(i+" is not a Harshad or Niven Number");
        else
        {
            int n1=i;
            int b=0;
            while(n1>0)
            {
                int a2;
                a2 = n1%10;
                b=b+a2;
                n1=n1/10;
            }
            int w;
            try
            {
                w=i%b;
            }catch(Exception e)
            {
                w=b%i;
            }
            if(w==0)
            {
                if(a==1)
                {
                    res.append(i+"\n");
                    z++;
                }else if(a==2)
                    res.setText(i+" is a Harshad or Niven Number");
            }
            else if(a==2)
                res.setText(i+" is not a Harshad or Niven Number");
        }
    }
    
    void Increasing(int n)
    {
        if(isIncreasing(n)==true)
        {
            if(a==1)
            {    res.append(n + "\n");
            z++;
                }else if(a==2)
                res.setText(n+" is a Increasing Number");
        }
        else if(a==2)
        {
            res.setText(n+" is not a Increasing Number");
        }
    }
    void Kaprekar(int i)
    {
             
            int sq = i*i; 
            String s = Integer.toString(sq); 
            if(sq<=9)
            {
                s = "0"+s; 
            }
            int l = s.length(); 
            int mid = l/2; 
            String left=s.substring(0,mid);
            String right=s.substring(mid);
            int x = Integer.parseInt(left); 
            int y = Integer.parseInt(right); 
            if(x+y == i) 
            {   
                if(a==1)
                {
                    res.append(i+"\n");
                    z++;
                }else if(a==2)
                    res.setText(i+" is a Kaprekar Number");
            }
            else if(a==2)
                res.setText(i+" is not a Kaprekar Number");      
    }
    void Keith(int n)
    {
        if((n==0||n==1) && a==2)
            res.setText(n+" is not a Keith Number");
        else
        {
            int copy=n;
            String s=Integer.toString(n);
            int d=s.length(); //finding the number of digits (d) in the number
            int arr[]=new int[n]; //array for storing the terms of the series
            for(int i=d-1; i>=0; i--)
            {
                arr[i]=copy%10; //storing the digits of the number in the array
                copy=copy/10;  
            }
            int i=d,sum=0;
            while(sum<n) //finding the sum till it is less than the number
            {
                sum = 0;
                for(int j=1; j<=d; j++) //loop for generating and adding the previous 'd' terms
                {
                    sum=sum+arr[i-j];
                }
                arr[i]=sum; //storing the sum in the array
                i++;
            }
            if(sum==n) //if sum is equal to the number, then it is a Keith number
            {
                if(a==1)
                {
                    res.append(n+"\n");
                    z++;
                }else if(a==2)
                    res.setText(n+" is Keith Number");
            }
            else if(a==2)
                res.setText(n+" is not a Keith Number");
        }   
    }
    void krishnamurthy(int i)
    {
                 
            int r=i;
            int s;
            s = 0;
            while(r>0)
            {
                int t=r%10;
                int f=1;
                for(int j=1;j<=t;j++)
                {
                    f=f*j;
                }
                s=s+f;
                r=r/10;
            }
            if(s==i)
            {
                if(a==1)
                {
                    res.append(s+"\n");
                    z++;
                }else if(a==2)
                    res.setText(i+" is a Krishnamurthy number");
            }
            else if (a==2)
                res.setText(i+" is not a Krishnamurthy Number.");
        
    }
    void Magic(int n)
    {
        int sum,num=n;
        while(num>9)
        {
            sum=num;int s=0;
            while(sum!=0)
            {
                s=s+(sum%10);
                sum=sum/10;
            }
            num=s;
        }
        if(num==1)
        {
            if(a==1)
            {
                res.append(n+"\n");
                z++;
            }
            else if(a==2)
                    res.setText(n+" is a Magic Number");
        }
        else if(a==2)
                res.setText(n+" is not a Magic Number");
    }
    void Pallindrome(int i)
    {
                
            int d=i;
            int r;
            r = 0;
            while(d>0)
            {
                int b=d%10;
                r=r*10+b;
                d=d/10;
            }
            if(r==i)
            {
                if(a==1)
                {
                    res.append(r+"\n");
                    z++;
                }
                else if(a==2)
                    res.setText(i+" is a Pallindrome Number.");
            }
            else if(a==2)
                res.setText(i+" is not a Pallindrome Number.");
    }
    void Perfect(int n)
    {
        int i=1,s=0,n1=n;
        do
        {
            int y=n1%i;
            if(y==0)
            {
                s=s+i;
            }
            i++;
        }
        while(i<n);
        if(n==s)
        {
            if(a==1)
            {    res.append(n+"\n");
            z++;
                }else if(a==2)
                res.setText(n+" is a Perfect Number");
        }
        else if(a==2)
            res.setText(n+" is not a Perfect Number");
    }
    void Pronic(int n)
    {
        int d=0;
        for(int i=1;i<=n;i++)
        {
            int b=i*(i+1);
            if(b==n)
            {
                d++;
            }
        }
        if(d>=1)
        {
            if(a==1)
            {
                z++;
                res.append(n+"\n");
            }else if(a==2)
                res.setText(n+" is a Pronic number");
        }
        else if(a==2)
            res.setText(n+" is not a pronic number");
    }
    void Smith(int n)
    {
        int n1=n;
        int s=0;
        while(n1>0)
        {
            s=s+n1%10;
            n1=n1/10;
        }
        int n2=n;
        int i=2, sum=0;
        while(n2>1)
        {
            if(n2%i==0)
            {
                int t=0;
                n1=i;
                while(n1>0)
                {
                    t=t+n1%10;
                    n1=n1/10;
                }
                sum=sum+t; //Here 'i' is the prime factor of 'n' and we are finding its sum
                n2=n2/i;
            }
            else
                i++;
        }
        if(s==sum)
        {
            if(a==1)
            {
                z++;
                res.append(n+"\n");
            }else if(a==2)
                res.setText(n+" is a Smith Number");
        }
        else if(a==2)
            res.setText(n+" is not a Smith Number");
    }
    void Twin_Prime()
    {
        z=0;
        int p=Integer.parseInt(r1.getText());
        int q=Integer.parseInt(r2.getText());
                
                for(int i=p; i<=(q-2); i++)
                {
                    if(isPrime(i) == true && isPrime(i+2) == true)
                    {
                        res.append("("+i+","+(i+2)+") \n");
                        z++;
                    }
                }
                vison();
                countd.setText(z+" "); 
                ch.setText("Twin Prime");
    }
    void Unique(int n)
    {
        String s=Integer.toString(n); //converting the number into String form
        int l=s.length();
        int flag=0;
        for(int i=0;i<l-1;i++)
        {
            for(int j=i+1;j<l;j++)
            {
                if(s.charAt(i)==s.charAt(j)) //if any digits match, then we know it is not a Unique Number
                {
                    flag=1;
                    break;
                }
            }
        }
        if(flag==0)
        {
            if(a==1) 
            {
                z++;
                res.append(n+"\n");
            }else if(a==2)
                    res.setText(n+" is a Unique Number");
        }
        else if(a==2)
            res.setText(n+" is not a Unique Number");
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KnowYourNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KnowYourNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KnowYourNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KnowYourNumber.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new KnowYourNumber().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JFrame abou;
    private javax.swing.JFrame armI;
    private javax.swing.JFrame autoI;
    private javax.swing.JFrame bounI;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel ch;
    private javax.swing.JRadioButton che;
    private javax.swing.JComboBox<String> choice;
    private javax.swing.JLabel countd;
    private javax.swing.JFrame decI;
    private javax.swing.JFrame disI;
    private javax.swing.JFrame ducI;
    private javax.swing.JFrame eviI;
    private javax.swing.JFrame fasI;
    private javax.swing.JFrame harI;
    private javax.swing.JTextArea i1;
    private javax.swing.JTextArea i10;
    private javax.swing.JTextArea i11;
    private javax.swing.JTextArea i12;
    private javax.swing.JTextArea i13;
    private javax.swing.JTextArea i14;
    private javax.swing.JTextArea i15;
    private javax.swing.JTextArea i16;
    private javax.swing.JTextArea i17;
    private javax.swing.JTextArea i18;
    private javax.swing.JTextArea i2;
    private javax.swing.JTextArea i22;
    private javax.swing.JTextArea i23;
    private javax.swing.JTextArea i24;
    private javax.swing.JTextArea i25;
    private javax.swing.JTextArea i26;
    private javax.swing.JTextArea i27;
    private javax.swing.JTextArea i28;
    private javax.swing.JTextArea i29;
    private javax.swing.JTextArea i3;
    private javax.swing.JTextArea i30;
    private javax.swing.JTextArea i31;
    private javax.swing.JTextArea i32;
    private javax.swing.JTextArea i33;
    private javax.swing.JTextArea i34;
    private javax.swing.JTextArea i35;
    private javax.swing.JTextArea i36;
    private javax.swing.JTextArea i37;
    private javax.swing.JTextArea i38;
    private javax.swing.JTextArea i39;
    private javax.swing.JTextArea i4;
    private javax.swing.JTextArea i40;
    private javax.swing.JTextArea i41;
    private javax.swing.JTextArea i42;
    private javax.swing.JTextArea i43;
    private javax.swing.JTextArea i44;
    private javax.swing.JTextArea i45;
    private javax.swing.JTextArea i46;
    private javax.swing.JTextArea i47;
    private javax.swing.JTextArea i48;
    private javax.swing.JTextArea i49;
    private javax.swing.JTextArea i5;
    private javax.swing.JTextArea i50;
    private javax.swing.JTextArea i51;
    private javax.swing.JTextArea i52;
    private javax.swing.JTextArea i53;
    private javax.swing.JTextArea i54;
    private javax.swing.JTextArea i55;
    private javax.swing.JTextArea i56;
    private javax.swing.JTextArea i57;
    private javax.swing.JTextArea i58;
    private javax.swing.JTextArea i59;
    private javax.swing.JTextArea i6;
    private javax.swing.JTextArea i60;
    private javax.swing.JTextArea i61;
    private javax.swing.JTextArea i62;
    private javax.swing.JTextArea i63;
    private javax.swing.JTextArea i64;
    private javax.swing.JTextArea i7;
    private javax.swing.JTextArea i8;
    private javax.swing.JTextArea i9;
    private javax.swing.JFrame incI;
    private javax.swing.JButton info;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JOptionPane jOptionPane;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane26;
    private javax.swing.JScrollPane jScrollPane27;
    private javax.swing.JScrollPane jScrollPane28;
    private javax.swing.JScrollPane jScrollPane29;
    private javax.swing.JScrollPane jScrollPane30;
    private javax.swing.JScrollPane jScrollPane31;
    private javax.swing.JScrollPane jScrollPane32;
    private javax.swing.JScrollPane jScrollPane33;
    private javax.swing.JScrollPane jScrollPane34;
    private javax.swing.JScrollPane jScrollPane35;
    private javax.swing.JScrollPane jScrollPane36;
    private javax.swing.JScrollPane jScrollPane37;
    private javax.swing.JScrollPane jScrollPane38;
    private javax.swing.JScrollPane jScrollPane39;
    private javax.swing.JScrollPane jScrollPane40;
    private javax.swing.JScrollPane jScrollPane41;
    private javax.swing.JScrollPane jScrollPane42;
    private javax.swing.JScrollPane jScrollPane43;
    private javax.swing.JScrollPane jScrollPane44;
    private javax.swing.JScrollPane jScrollPane45;
    private javax.swing.JScrollPane jScrollPane46;
    private javax.swing.JScrollPane jScrollPane47;
    private javax.swing.JScrollPane jScrollPane48;
    private javax.swing.JScrollPane jScrollPane49;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane50;
    private javax.swing.JScrollPane jScrollPane51;
    private javax.swing.JScrollPane jScrollPane52;
    private javax.swing.JScrollPane jScrollPane53;
    private javax.swing.JScrollPane jScrollPane54;
    private javax.swing.JScrollPane jScrollPane55;
    private javax.swing.JScrollPane jScrollPane56;
    private javax.swing.JScrollPane jScrollPane57;
    private javax.swing.JScrollPane jScrollPane58;
    private javax.swing.JScrollPane jScrollPane59;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane60;
    private javax.swing.JScrollPane jScrollPane61;
    private javax.swing.JScrollPane jScrollPane62;
    private javax.swing.JScrollPane jScrollPane63;
    private javax.swing.JScrollPane jScrollPane64;
    private javax.swing.JScrollPane jScrollPane65;
    private javax.swing.JScrollPane jScrollPane66;
    private javax.swing.JScrollPane jScrollPane67;
    private javax.swing.JScrollPane jScrollPane68;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane10;
    private javax.swing.JTabbedPane jTabbedPane11;
    private javax.swing.JTabbedPane jTabbedPane12;
    private javax.swing.JTabbedPane jTabbedPane13;
    private javax.swing.JTabbedPane jTabbedPane14;
    private javax.swing.JTabbedPane jTabbedPane15;
    private javax.swing.JTabbedPane jTabbedPane16;
    private javax.swing.JTabbedPane jTabbedPane17;
    private javax.swing.JTabbedPane jTabbedPane18;
    private javax.swing.JTabbedPane jTabbedPane19;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane20;
    private javax.swing.JTabbedPane jTabbedPane21;
    private javax.swing.JTabbedPane jTabbedPane22;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTabbedPane jTabbedPane6;
    private javax.swing.JTabbedPane jTabbedPane7;
    private javax.swing.JTabbedPane jTabbedPane9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JFrame kapI;
    private javax.swing.JFrame keiI;
    private javax.swing.JButton key1;
    private javax.swing.JFrame kriI;
    private javax.swing.JFrame magI;
    private javax.swing.JRadioButton no;
    private javax.swing.JFrame palI;
    private javax.swing.JFrame perI;
    private javax.swing.JFrame proI;
    private javax.swing.JTextField r1;
    private javax.swing.JTextField r2;
    private javax.swing.JTextField r3;
    private javax.swing.JRadioButton range;
    private javax.swing.JTextArea res;
    private javax.swing.JFrame smiI;
    private javax.swing.JLabel t1;
    private javax.swing.JLabel t2;
    private javax.swing.JFrame twiI;
    private javax.swing.JFrame uniI;
    // End of variables declaration//GEN-END:variables
}